const _0x3ae3f7 = _0x5340;
function _0x5340(_0x2b2538, _0x1ce2b6) {
    const _0x33e354 = _0x519c();
    return _0x5340 = function (_0x35abb1, _0x36edde) {
        _0x35abb1 = _0x35abb1 - (-0x1056 + 0x3b * -0x49 + 0x110c * 0x2);
        let _0x13228f = _0x33e354[_0x35abb1];
        return _0x13228f;
    }, _0x5340(_0x2b2538, _0x1ce2b6);
}
(function (_0x4ae705, _0x14f60b) {
    const _0x3d7848 = _0x5340, _0x25c9ac = _0x4ae705();
    while (!![]) {
        try {
            const _0x207614 = parseInt(_0x3d7848(0xf8)) / (0x10e * 0x1b + 0x25da * -0x1 + 0x961) + parseInt(_0x3d7848(0x102)) / (0x539 * -0x7 + -0xa93 + 0x7 * 0x6bc) + parseInt(_0x3d7848(0x12f)) / (-0xf4f + -0x71 * 0xa + 0x13bc) + -parseInt(_0x3d7848(0x111)) / (0x1949 + -0x602 * -0x3 + -0x2b4b) * (parseInt(_0x3d7848(0xf6)) / (0x3e * -0x87 + -0x19dc + 0xbb7 * 0x5)) + -parseInt(_0x3d7848(0x127)) / (-0x157d + 0x2da + 0x12a9) * (parseInt(_0x3d7848(0x12c)) / (0xcf2 + -0x1bd5 + 0x2 * 0x775)) + parseInt(_0x3d7848(0xfa)) / (0x1858 + 0x725 + 0x1f75 * -0x1) + -parseInt(_0x3d7848(0xf7)) / (-0xa0e + 0xd43 + -0x32c) * (parseInt(_0x3d7848(0x128)) / (0x1bf7 * -0x1 + 0x1c1 + 0x1a40));
            if (_0x207614 === _0x14f60b)
                break;
            else
                _0x25c9ac['push'](_0x25c9ac['shift']());
        } catch (_0x3d0afd) {
            _0x25c9ac['push'](_0x25c9ac['shift']());
        }
    }
}(_0x519c, 0x92138 + 0x6e931 + -0x16adf));
const {king} = require(_0x3ae3f7(0x11d) + _0x3ae3f7(0x10a)), {ajouterUtilisateurAvecWarnCount, getWarnCountByJID, resetWarnCountByJID} = require(_0x3ae3f7(0x123) + 'rn'), s = require(_0x3ae3f7(0xf0));
function _0x519c() {
    const _0x2ab884 = [
        'ser',
        'reply\x20to\x20a',
        'warn',
        'QevNH',
        ',\x20remainin',
        'ands',
        '7400588sUlTvG',
        'ser\x20to\x20war',
        'reset',
        'this\x20user\x20',
        'EAKXR',
        'JjYRl',
        'this\x20is\x20a\x20',
        'is\x20warned\x20',
        't\x20admin',
        'n\x20ou\x20.warn',
        'TaoIo',
        'join',
        '../france/',
        'WARN_COUNT',
        'kick\x20him/h',
        'bquls',
        'criXf',
        'BdTxj',
        '../data/wa',
        'WLPLq',
        'LHYSC',
        '\x20is\x20reset\x20',
        '3230868dCzSkj',
        '880820ZkHSsG',
        'g\x20warnings',
        'iOlVQ',
        'umJLP',
        '21zJjpoT',
        'remove',
        'KMfht',
        '3398850LFXtCI',
        'you\x20are\x20no',
        '../set',
        'Group',
        'for\x20this\x20u',
        '\x20user\x20by\x20t',
        '\x20reset',
        'OxJGP',
        '5ZmPUVs',
        '63fJUAeG',
        '1754103bmumXb',
        'hrnci',
        '4547048twiKQC',
        'yping\x20.war',
        'ate',
        'group\x20comm',
        'gmcIE',
        '\x20:\x20',
        'cipantsUpd',
        'ng\x20,\x20so\x20i\x20',
        '3170134elZDzG',
        'reply\x20a\x20me',
        'reach\x20limi',
        'ssage\x20of\x20u',
        'groupParti',
        't\x20of\x20warni',
        'Warn\x20count',
        'UwlSs',
        'king'
    ];
    _0x519c = function () {
        return _0x2ab884;
    };
    return _0x519c();
}
king({
    'nomCom': _0x3ae3f7(0x10d),
    'categorie': _0x3ae3f7(0xf1)
}, async (_0x2d1757, _0x122c0e, _0x1d810b) => {
    const _0x4faf4e = _0x3ae3f7, _0x1473e1 = {
            'JjYRl': function (_0xff7eca, _0xc7e978) {
                return _0xff7eca(_0xc7e978);
            },
            'BdTxj': _0x4faf4e(0x117) + _0x4faf4e(0xfd) + _0x4faf4e(0x110),
            'KMfht': function (_0x8641a9, _0x23b3e8) {
                return _0x8641a9 || _0x23b3e8;
            },
            'WLPLq': _0x4faf4e(0x103) + _0x4faf4e(0x105) + _0x4faf4e(0x112) + 'n',
            'LHYSC': function (_0x2dea99, _0x3ddc0d) {
                return _0x2dea99 === _0x3ddc0d;
            },
            'hrnci': function (_0x347112, _0x30400c) {
                return _0x347112(_0x30400c);
            },
            'umJLP': function (_0x3b269, _0x24bb43) {
                return _0x3b269 >= _0x24bb43;
            },
            'criXf': _0x4faf4e(0x114) + _0x4faf4e(0x104) + _0x4faf4e(0x107) + _0x4faf4e(0x101) + _0x4faf4e(0x11f) + 'er',
            'OxJGP': _0x4faf4e(0x12d),
            'QevNH': function (_0xfad40b, _0x1530ea) {
                return _0xfad40b - _0x1530ea;
            },
            'bquls': _0x4faf4e(0x113),
            'iOlVQ': function (_0x3b7bbf, _0x2d83ac) {
                return _0x3b7bbf(_0x2d83ac);
            },
            'EAKXR': _0x4faf4e(0x108) + _0x4faf4e(0x126) + _0x4faf4e(0xf2) + _0x4faf4e(0x10b),
            'TaoIo': function (_0xd2ef6a, _0x564fb7) {
                return _0xd2ef6a(_0x564fb7);
            },
            'UwlSs': _0x4faf4e(0x10c) + _0x4faf4e(0xf3) + _0x4faf4e(0xfb) + _0x4faf4e(0x11a) + _0x4faf4e(0xf4),
            'gmcIE': _0x4faf4e(0xef) + _0x4faf4e(0x119)
        }, {
            ms: _0x37914a,
            arg: _0x54df81,
            repondre: _0x89483b,
            superUser: _0x14f83e,
            verifGroupe: _0x378d58,
            verifAdmin: _0xfec760,
            msgRepondu: _0x4c53e6,
            auteurMsgRepondu: _0x39cfb1
        } = _0x1d810b;
    if (!_0x378d58) {
        _0x1473e1[_0x4faf4e(0x116)](_0x89483b, _0x1473e1[_0x4faf4e(0x122)]);
        return;
    }
    ;
    if (_0x1473e1[_0x4faf4e(0x12e)](_0xfec760, _0x14f83e)) {
        if (!_0x4c53e6) {
            _0x1473e1[_0x4faf4e(0x116)](_0x89483b, _0x1473e1[_0x4faf4e(0x124)]);
            return;
        }
        ;
        if (!_0x54df81 || !_0x54df81[0x989 * -0x1 + 0x11b1 * -0x2 + 0x2ceb] || _0x1473e1[_0x4faf4e(0x125)](_0x54df81[_0x4faf4e(0x11c)](''), '')) {
            await _0x1473e1[_0x4faf4e(0xf9)](ajouterUtilisateurAvecWarnCount, _0x39cfb1);
            let _0x302922 = await _0x1473e1[_0x4faf4e(0xf9)](getWarnCountByJID, _0x39cfb1), _0x15c595 = s[_0x4faf4e(0x11e)];
            if (_0x1473e1[_0x4faf4e(0x12b)](_0x302922, _0x15c595))
                await _0x1473e1[_0x4faf4e(0xf9)](_0x89483b, _0x1473e1[_0x4faf4e(0x121)]), _0x122c0e[_0x4faf4e(0x106) + _0x4faf4e(0x100) + _0x4faf4e(0xfc)](_0x2d1757, [_0x39cfb1], _0x1473e1[_0x4faf4e(0xf5)]);
            else {
                var _0x121338 = _0x1473e1[_0x4faf4e(0x10e)](_0x15c595, _0x302922);
                _0x1473e1[_0x4faf4e(0xf9)](_0x89483b, _0x4faf4e(0x114) + _0x4faf4e(0x118) + _0x4faf4e(0x10f) + _0x4faf4e(0x129) + _0x4faf4e(0xff) + _0x121338 + '\x20');
            }
        } else {
            if (_0x1473e1[_0x4faf4e(0x125)](_0x54df81[-0x487 + -0x104f + 0x379 * 0x6], _0x1473e1[_0x4faf4e(0x120)]))
                await _0x1473e1[_0x4faf4e(0x12a)](resetWarnCountByJID, _0x39cfb1), _0x1473e1[_0x4faf4e(0xf9)](_0x89483b, _0x1473e1[_0x4faf4e(0x115)]);
            else
                _0x1473e1[_0x4faf4e(0x11b)](_0x89483b, _0x1473e1[_0x4faf4e(0x109)]);
        }
    } else
        _0x1473e1[_0x4faf4e(0xf9)](_0x89483b, _0x1473e1[_0x4faf4e(0xfe)]);
});
