function _0x3cf2() {
    const _0x46d11e = [
        'bonk',
        'TqQdv',
        '\x22\x20./',
        '9WvVpzP',
        'readFileSy',
        'awoo',
        'nom',
        'url',
        'kiss',
        'lick',
        'sendMessag',
        'cuddle',
        'p\x20-vf\x20\x22sca',
        'happy',
        'le=trunc(i',
        '2693912kjlNHU',
        'zjJPa',
        'child_proc',
        '68973dvtUxt',
        'pat',
        'lags\x20fasts',
        'UyciA',
        'RmiRs',
        'oWeWw',
        'all',
        'w/2)*2:tru',
        '3639560McEVhj',
        '.gif\x20-movf',
        'random',
        '14922536gMnpXW',
        '\x20retrievin',
        'yeet',
        'glomp',
        'https://ap',
        'rBzEx',
        'king',
        'nc(ih/2)*2',
        'ffmpeg\x20-i\x20',
        'get',
        'UWAhX',
        '.mp4',
        '1068531FhCrJI',
        'sDVSH',
        'poke',
        'dance',
        'Error\x20occu',
        'axios',
        'smile',
        'bully',
        'kill',
        '\x20everyone',
        'tart\x20-pix_',
        'blush',
        'handhold',
        'highfive',
        'ess',
        'i.waifu.pi',
        '.gif',
        'pBjLc',
        'g\x20data:',
        'cringe',
        'cs/sfw/',
        'kick',
        'hug',
        'promises',
        'arraybuffe',
        'smug',
        'Reaction',
        '../france/',
        'rred\x20while',
        'bite',
        'wave',
        'fmt\x20yuv420',
        '63JBCuxL',
        'split',
        'toString',
        'cry',
        'CsmnS',
        'log',
        'data',
        'writeFileS',
        'ync',
        '609108PInGbD',
        '1744060QPaqGK',
        'slap',
        'fs-extra',
        'exec',
        'wink'
    ];
    _0x3cf2 = function () {
        return _0x46d11e;
    };
    return _0x3cf2();
}
const _0x4db2ed = _0x24a5;
(function (_0x4e7fd3, _0x14fff2) {
    const _0xcfcb2b = _0x24a5, _0x31fe79 = _0x4e7fd3();
    while (!![]) {
        try {
            const _0x31e429 = parseInt(_0xcfcb2b(0x1ff)) / (0x6c4 * -0x2 + 0x1655 + 0x4 * -0x233) + parseInt(_0xcfcb2b(0x1d1)) / (-0x1292 + 0x1816 + 0x6 * -0xeb) + -parseInt(_0xcfcb2b(0x1e8)) / (0x2d9 + 0x159a + -0x88 * 0x2e) + parseInt(_0xcfcb2b(0x1e5)) / (0xc11 * 0x1 + 0x4 * 0x77f + -0x2a09) + parseInt(_0xcfcb2b(0x1f0)) / (0x2665 * -0x1 + -0x1418 + -0x1d41 * -0x2) + -parseInt(_0xcfcb2b(0x1d0)) / (0x135c + -0x2 * 0xb60 + -0x17 * -0x26) * (parseInt(_0xcfcb2b(0x21f)) / (-0x7 * -0x13d + -0x2 * 0x54a + 0x1f0)) + parseInt(_0xcfcb2b(0x1f3)) / (-0x5d8 + 0x2377 + -0x19 * 0x12f) * (-parseInt(_0xcfcb2b(0x1d9)) / (-0xa * -0x8f + -0x18e4 + 0x1357));
            if (_0x31e429 === _0x14fff2)
                break;
            else
                _0x31fe79['push'](_0x31fe79['shift']());
        } catch (_0x2e4687) {
            _0x31fe79['push'](_0x31fe79['shift']());
        }
    }
}(_0x3cf2, 0x106af * -0x1 + 0x3f58d + 0x1 * 0x54e6f));
function _0x24a5(_0x5d0d39, _0xe3593f) {
    const _0x5e1cd7 = _0x3cf2();
    return _0x24a5 = function (_0x33688a, _0x4924f5) {
        _0x33688a = _0x33688a - (-0x5 * -0x45b + 0x922 + 0x1d21 * -0x1);
        let _0x57e934 = _0x5e1cd7[_0x33688a];
        return _0x57e934;
    }, _0x24a5(_0x5d0d39, _0xe3593f);
}
const axios = require(_0x4db2ed(0x204)), {king} = require(_0x4db2ed(0x21a) + _0x4db2ed(0x1f9)), fs = require(_0x4db2ed(0x1d3)), {exec} = require(_0x4db2ed(0x1e7) + _0x4db2ed(0x20d)), child_process = require(_0x4db2ed(0x1e7) + _0x4db2ed(0x20d)), {unlink} = require('fs')[_0x4db2ed(0x216)], sleep = _0x3327c5 => {
        const _0x5c3125 = {
            'CsmnS': function (_0xb7aee2, _0x2ed62a, _0x5b98e1) {
                return _0xb7aee2(_0x2ed62a, _0x5b98e1);
            }
        };
        return new Promise(_0x219bce => {
            const _0xf51420 = _0x24a5;
            _0x5c3125[_0xf51420(0x1cb)](setTimeout, _0x219bce, _0x3327c5);
        });
    }, GIFBufferToVideoBuffer = async _0x2ef3da => {
        const _0x296fdd = _0x4db2ed, _0x53b0d0 = {
                'rBzEx': function (_0x35b934, _0x176a9f) {
                    return _0x35b934(_0x176a9f);
                },
                'oWeWw': function (_0x5354df, _0x5596dd) {
                    return _0x5354df(_0x5596dd);
                }
            }, _0x2f516a = '' + Math[_0x296fdd(0x1f2)]()[_0x296fdd(0x1c9)](0x1bf2 + -0x1543 + 0x5 * -0x14f);
        await fs[_0x296fdd(0x1ce) + _0x296fdd(0x1cf)]('./' + _0x2f516a + _0x296fdd(0x20f), _0x2ef3da), child_process[_0x296fdd(0x1d4)](_0x296fdd(0x1fb) + './' + _0x2f516a + (_0x296fdd(0x1f1) + _0x296fdd(0x1ea) + _0x296fdd(0x209) + _0x296fdd(0x21e) + _0x296fdd(0x1e2) + _0x296fdd(0x1e4) + _0x296fdd(0x1ef) + _0x296fdd(0x1fa) + _0x296fdd(0x1d8)) + _0x2f516a + _0x296fdd(0x1fe)), await _0x53b0d0[_0x296fdd(0x1f8)](sleep, 0x1cd7 * -0x1 + 0x30b + 0x296c);
        var _0x206329 = await fs[_0x296fdd(0x1da) + 'nc']('./' + _0x2f516a + _0x296fdd(0x1fe));
        return Promise[_0x296fdd(0x1ee)]([
            _0x53b0d0[_0x296fdd(0x1ed)](unlink, './' + _0x2f516a + _0x296fdd(0x1fe)),
            _0x53b0d0[_0x296fdd(0x1ed)](unlink, './' + _0x2f516a + _0x296fdd(0x20f))
        ]), _0x206329;
    }, generateReactionCommand = (_0x5a5d56, _0x204113) => {
        const _0x30636e = _0x4db2ed, _0x2cac32 = {
                'UyciA': _0x30636e(0x217) + 'r',
                'pBjLc': function (_0x324ae6, _0x4d0466) {
                    return _0x324ae6(_0x4d0466);
                },
                'zjJPa': function (_0x24779c, _0x2e75da) {
                    return _0x24779c(_0x2e75da);
                },
                'TqQdv': function (_0x61b2d0, _0x4d9db9) {
                    return _0x61b2d0 + _0x4d9db9;
                },
                'RmiRs': _0x30636e(0x203) + _0x30636e(0x21b) + _0x30636e(0x1f4) + _0x30636e(0x211),
                'UWAhX': function (_0x21021a, _0x93f28d, _0x345061) {
                    return _0x21021a(_0x93f28d, _0x345061);
                },
                'sDVSH': _0x30636e(0x219)
            };
        _0x2cac32[_0x30636e(0x1fd)](king, {
            'nomCom': _0x5a5d56,
            'categorie': _0x2cac32[_0x30636e(0x200)],
            'reaction': _0x204113
        }, async (_0x1a3eee, _0x4e6205, _0x5bfba4) => {
            const _0x3c790f = _0x30636e, {
                    auteurMessage: _0x2aa4a7,
                    auteurMsgRepondu: _0x1a4c8c,
                    repondre: _0x22d58c,
                    ms: _0x236262,
                    msgRepondu: _0x353440
                } = _0x5bfba4, _0x41655b = _0x3c790f(0x1f7) + _0x3c790f(0x20e) + _0x3c790f(0x213) + _0x5a5d56;
            try {
                const _0x46c202 = await axios[_0x3c790f(0x1fc)](_0x41655b), _0x450851 = _0x46c202[_0x3c790f(0x1cd)][_0x3c790f(0x1dd)], _0x4f53a8 = await axios[_0x3c790f(0x1fc)](_0x450851, { 'responseType': _0x2cac32[_0x3c790f(0x1eb)] }), _0x2b54ea = await _0x4f53a8[_0x3c790f(0x1cd)], _0x11b618 = await _0x2cac32[_0x3c790f(0x210)](GIFBufferToVideoBuffer, _0x2b54ea);
                if (_0x353440) {
                    var _0x502818 = '\x20@' + _0x2aa4a7[_0x3c790f(0x1c8)]('@')[-0x3be + 0x391 + 0x2d] + '\x20' + _0x5a5d56 + '\x20@' + _0x1a4c8c[_0x3c790f(0x1c8)]('@')[-0x3 * 0x147 + 0x971 * -0x4 + -0x1cf * -0x17];
                    _0x4e6205[_0x3c790f(0x1e0) + 'e'](_0x1a3eee, {
                        'video': _0x11b618,
                        'gifPlayback': !![],
                        'caption': _0x502818,
                        'mentions': [
                            _0x2aa4a7,
                            _0x1a4c8c
                        ]
                    }, { 'quoted': _0x236262 });
                } else {
                    const _0x527b54 = {
                        'video': _0x11b618,
                        'gifPlayback': !![],
                        'caption': '@' + _0x2aa4a7[_0x3c790f(0x1c8)]('@')[0x91c + 0x1 * -0x11a5 + 0x889] + '\x20' + _0x5a5d56 + _0x3c790f(0x208),
                        'mentions': [_0x2aa4a7]
                    };
                    _0x4e6205[_0x3c790f(0x1e0) + 'e'](_0x1a3eee, _0x527b54, { 'quoted': _0x236262 });
                }
            } catch (_0x1202e9) {
                _0x2cac32[_0x3c790f(0x1e6)](_0x22d58c, _0x2cac32[_0x3c790f(0x1d7)](_0x2cac32[_0x3c790f(0x1ec)], _0x1202e9)), console[_0x3c790f(0x1cc)](_0x1202e9);
            }
        });
    };
generateReactionCommand(_0x4db2ed(0x206), '👊'), generateReactionCommand(_0x4db2ed(0x1e1), '🤗'), generateReactionCommand(_0x4db2ed(0x1ca), '😢'), generateReactionCommand(_0x4db2ed(0x215), '😊'), generateReactionCommand(_0x4db2ed(0x1db), '🐺'), generateReactionCommand(_0x4db2ed(0x1de), '😘'), generateReactionCommand(_0x4db2ed(0x1df), '👅'), generateReactionCommand(_0x4db2ed(0x1e9), '👋'), generateReactionCommand(_0x4db2ed(0x218), '😏'), generateReactionCommand(_0x4db2ed(0x1d6), '🔨'), generateReactionCommand(_0x4db2ed(0x1f5), '🚀'), generateReactionCommand(_0x4db2ed(0x20a), '😊'), generateReactionCommand(_0x4db2ed(0x205), '😄'), generateReactionCommand(_0x4db2ed(0x21d), '👋'), generateReactionCommand(_0x4db2ed(0x20c)), generateReactionCommand(_0x4db2ed(0x20b)), generateReactionCommand(_0x4db2ed(0x1dc), '👅'), generateReactionCommand(_0x4db2ed(0x21c), '🦷'), generateReactionCommand(_0x4db2ed(0x1f6), '🤗'), generateReactionCommand(_0x4db2ed(0x1d2), '👋'), generateReactionCommand(_0x4db2ed(0x207), '💀'), generateReactionCommand(_0x4db2ed(0x214), '🦵'), generateReactionCommand(_0x4db2ed(0x1e3), '😄'), generateReactionCommand(_0x4db2ed(0x1d5), '😉'), generateReactionCommand(_0x4db2ed(0x201), '👉'), generateReactionCommand(_0x4db2ed(0x202), '💃'), generateReactionCommand(_0x4db2ed(0x212), '😬');
